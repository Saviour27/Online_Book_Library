﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace MyLibrary.Migrations
{
    /// <inheritdoc />
    public partial class newlycreated : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Books",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Books",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Books",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Books",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Books",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.UpdateData(
                table: "Books",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "LibraryAddDate", "UpdatedAt" },
                values: new object[] { new DateTime(2023, 11, 28, 11, 54, 16, 876, DateTimeKind.Local).AddTicks(1934), new DateTime(2023, 11, 28, 11, 54, 16, 876, DateTimeKind.Local).AddTicks(1919), new DateTime(2023, 11, 28, 11, 54, 16, 876, DateTimeKind.Local).AddTicks(1940) });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Books",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "LibraryAddDate", "UpdatedAt" },
                values: new object[] { new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(387), new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(372), new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(390) });

            migrationBuilder.InsertData(
                table: "Books",
                columns: new[] { "Id", "Author", "AvailableCopies", "CopiesInLibrary", "CopiesOutLibrary", "CreatedAt", "DeletedAt", "Description", "EVersion", "GenreId", "ISBN", "ImageURL", "Language", "LibraryAddDate", "Pages", "Publisher", "Title", "UpdatedAt", "bookcategories" },
                values: new object[,]
                {
                    { 2, "J.K Rowling", 47, 50, 3, new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(396), null, "Magic", true, 1, "975609876112", "images/Fiction/drama/OIP", "English", new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(394), 780, "Bloomsbury", "Harry Potter and the Prisoner of Azkaban", new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(397), 0 },
                    { 3, "J.K Rowling", 47, 50, 3, new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(401), null, "Magic", true, 1, "975609876112", "images/Fiction/horror/1.jpeg", "English", new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(400), 780, "Bloomsbury", "Harry Potter and the Prisoner of Azkaban", new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(402), 0 },
                    { 4, "J.K Rowling", 47, 50, 3, new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(407), null, "Magic", true, 1, "975609876112", "images/Fiction/horror/2.jpeg", "English", new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(406), 780, "Bloomsbury", "Harry Potter and the Prisoner of Azkaban", new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(408), 0 },
                    { 5, "J.K Rowling", 47, 50, 3, new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(412), null, "Magic", true, 1, "975609876112", "images/Fiction/mystery/3.jpeg", "English", new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(411), 780, "Bloomsbury", "Harry Potter and the Prisoner of Azkaban", new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(413), 0 },
                    { 6, "J.K Rowling", 47, 50, 3, new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(417), null, "Magic", true, 1, "975609876112", "images/Fiction/mystery/4.jpeg", "English", new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(416), 780, "Bloomsbury", "Harry Potter and the Prisoner of Azkaban", new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(418), 0 }
                });
        }
    }
}
