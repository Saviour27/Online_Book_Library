﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MyLibrary.Migrations
{
    /// <inheritdoc />
    public partial class @new : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Books",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "LibraryAddDate", "UpdatedAt" },
                values: new object[] { new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(387), new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(372), new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(390) });

            migrationBuilder.UpdateData(
                table: "Books",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "CreatedAt", "LibraryAddDate", "UpdatedAt" },
                values: new object[] { new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(396), new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(394), new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(397) });

            migrationBuilder.UpdateData(
                table: "Books",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "CreatedAt", "LibraryAddDate", "UpdatedAt" },
                values: new object[] { new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(401), new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(400), new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(402) });

            migrationBuilder.UpdateData(
                table: "Books",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "CreatedAt", "LibraryAddDate", "UpdatedAt" },
                values: new object[] { new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(407), new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(406), new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(408) });

            migrationBuilder.UpdateData(
                table: "Books",
                keyColumn: "Id",
                keyValue: 5,
                columns: new[] { "CreatedAt", "LibraryAddDate", "UpdatedAt" },
                values: new object[] { new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(412), new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(411), new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(413) });

            migrationBuilder.UpdateData(
                table: "Books",
                keyColumn: "Id",
                keyValue: 6,
                columns: new[] { "CreatedAt", "LibraryAddDate", "UpdatedAt" },
                values: new object[] { new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(417), new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(416), new DateTime(2023, 11, 28, 10, 22, 8, 685, DateTimeKind.Local).AddTicks(418) });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Books",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "LibraryAddDate", "UpdatedAt" },
                values: new object[] { new DateTime(2023, 11, 28, 9, 50, 19, 132, DateTimeKind.Local).AddTicks(3112), new DateTime(2023, 11, 28, 9, 50, 19, 132, DateTimeKind.Local).AddTicks(3088), new DateTime(2023, 11, 28, 9, 50, 19, 132, DateTimeKind.Local).AddTicks(3117) });

            migrationBuilder.UpdateData(
                table: "Books",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "CreatedAt", "LibraryAddDate", "UpdatedAt" },
                values: new object[] { new DateTime(2023, 11, 28, 9, 50, 19, 132, DateTimeKind.Local).AddTicks(3130), new DateTime(2023, 11, 28, 9, 50, 19, 132, DateTimeKind.Local).AddTicks(3127), new DateTime(2023, 11, 28, 9, 50, 19, 132, DateTimeKind.Local).AddTicks(3132) });

            migrationBuilder.UpdateData(
                table: "Books",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "CreatedAt", "LibraryAddDate", "UpdatedAt" },
                values: new object[] { new DateTime(2023, 11, 28, 9, 50, 19, 132, DateTimeKind.Local).AddTicks(3140), new DateTime(2023, 11, 28, 9, 50, 19, 132, DateTimeKind.Local).AddTicks(3138), new DateTime(2023, 11, 28, 9, 50, 19, 132, DateTimeKind.Local).AddTicks(3142) });

            migrationBuilder.UpdateData(
                table: "Books",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "CreatedAt", "LibraryAddDate", "UpdatedAt" },
                values: new object[] { new DateTime(2023, 11, 28, 9, 50, 19, 132, DateTimeKind.Local).AddTicks(3149), new DateTime(2023, 11, 28, 9, 50, 19, 132, DateTimeKind.Local).AddTicks(3147), new DateTime(2023, 11, 28, 9, 50, 19, 132, DateTimeKind.Local).AddTicks(3150) });

            migrationBuilder.UpdateData(
                table: "Books",
                keyColumn: "Id",
                keyValue: 5,
                columns: new[] { "CreatedAt", "LibraryAddDate", "UpdatedAt" },
                values: new object[] { new DateTime(2023, 11, 28, 9, 50, 19, 132, DateTimeKind.Local).AddTicks(3157), new DateTime(2023, 11, 28, 9, 50, 19, 132, DateTimeKind.Local).AddTicks(3155), new DateTime(2023, 11, 28, 9, 50, 19, 132, DateTimeKind.Local).AddTicks(3158) });

            migrationBuilder.UpdateData(
                table: "Books",
                keyColumn: "Id",
                keyValue: 6,
                columns: new[] { "CreatedAt", "LibraryAddDate", "UpdatedAt" },
                values: new object[] { new DateTime(2023, 11, 28, 9, 50, 19, 132, DateTimeKind.Local).AddTicks(3164), new DateTime(2023, 11, 28, 9, 50, 19, 132, DateTimeKind.Local).AddTicks(3163), new DateTime(2023, 11, 28, 9, 50, 19, 132, DateTimeKind.Local).AddTicks(3166) });
        }
    }
}
