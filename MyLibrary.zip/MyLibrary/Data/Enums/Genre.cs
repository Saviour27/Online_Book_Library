﻿namespace MyLibrary.Data.Enums
{
    public enum Genre
    {
        Drama = 1,
        Horror,
        Mystery,
        Sci_Fi,
        Art,
        Biography,
        Sport,
        Travel,
        Blues,
        Classic,
        Folk,
        Hip_Hop,
        Rap,
        Reggea,
        Rock
    }
}